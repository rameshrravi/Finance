The XML files in directory com/itextpdf/text/pdf/hyphenation/hyph are NOT PART of the iText project.

These files are shared in a separate jar for your convenience. Most of the files are available under an Apache license, because they are also used in the Apache FOP project, but some XML files were sent to us by individual developers who obtained the files from different sources.

Please check the header of each individual file you need for its license!